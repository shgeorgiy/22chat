# Messenger: GitHub Pages + Google Apps Script directory + Cloudflare Quick Tunnel

## What this does

- `github-pages/` is the permanent static site for GitHub Pages.
- `backend/` is the Python API and SQLite database (run it on Mac or Raspberry Pi).
- `apps-script/Code.gs` stores the *current* temporary `trycloudflare.com` URL in a Google Sheet.
- the GitHub page reads that URL on load and once every minute using JSONP; this avoids Apps Script CORS limitations.
- The browser checks new messages every 5 seconds. Each direct chat keeps only the newest 22 messages.

## Part A — Google Sheet directory

1. Create a blank Google Sheet. Copy its ID from its URL:
   `https://docs.google.com/spreadsheets/d/SHEET_ID/edit`
2. In the sheet: **Extensions → Apps Script**.
3. Replace the file contents with `apps-script/Code.gs`.
4. Put your Sheet ID into `SPREADSHEET_ID`.
5. Replace `SECRET` with a long random value. Do not place this secret in GitHub.
6. **Deploy → New deployment → Web app**:
   - Execute as: **Me**
   - Who has access: **Anyone**
7. Copy the `/exec` web-app URL.
8. In `github-pages/index.html`, replace `PASTE_YOUR_APPS_SCRIPT_EXEC_URL_HERE` with that URL.

## Part B — Run the backend

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 app.py
```

Keep it running. Locally it is on `http://localhost:5000`.

In a **second** terminal:

```bash
cd backend
source .venv/bin/activate
export DIRECTORY_URL='PASTE_THE_APPS_SCRIPT_EXEC_URL_HERE'
export DIRECTORY_SECRET='PASTE_THE_SAME_SECRET_FROM_CODE_GS_HERE'
python3 start_tunnel.py
```

This starts Cloudflare Quick Tunnel and writes the newly-created URL to the Google Sheet. Never commit the secret to GitHub.

## Part C — Publish the site to GitHub Pages

1. Create a new GitHub repository, for example `messenger`.
2. Upload the **contents** of the `github-pages` folder — `index.html` must be in the repository root.
3. Repository → **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`.
5. GitHub gives you a permanent address like `https://YOUR-USERNAME.github.io/messenger/`.

## Security notes

- Anyone who knows the GitHub Pages URL can reach the login screen. They still need an account/password.
- The Apps Script URL itself is public; it only reveals the current public chat API endpoint, not passwords or messages.
- The `DIRECTORY_SECRET` only protects the endpoint that changes the tunnel address. Keep it private.
- Quick Tunnel is for testing and its URL changes whenever it restarts. The permanent solution is a Cloudflare named tunnel plus a domain.

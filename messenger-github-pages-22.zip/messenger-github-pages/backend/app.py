import base64
import hashlib
import os
import re
import secrets
import sqlite3
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, jsonify, request
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "messenger.db")
MAX_MESSAGES_PER_CHAT = 22
USERNAME_RE = re.compile(r"^[a-zA-Z0-9_]{3,24}$")

app = Flask(__name__)


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with db_connection() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE NOT NULL COLLATE NOCASE,
          password_hash TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tokens (
          token_hash TEXT PRIMARY KEY,
          user_id INTEGER NOT NULL,
          created_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS messages (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          sender_id INTEGER NOT NULL,
          recipient_id INTEGER NOT NULL,
          body TEXT NOT NULL,
          created_at TEXT NOT NULL,
          FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY(recipient_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_messages_pair_time
          ON messages(sender_id, recipient_id, id);
        """)
        # Keep existing databases within the same 22-message limit too.
        conn.execute("""
          DELETE FROM messages
          WHERE id IN (
            SELECT id FROM (
              SELECT id, ROW_NUMBER() OVER (
                PARTITION BY
                  CASE WHEN sender_id < recipient_id THEN sender_id ELSE recipient_id END,
                  CASE WHEN sender_id < recipient_id THEN recipient_id ELSE sender_id END
                ORDER BY id DESC
              ) AS row_num
              FROM messages
            ) WHERE row_num > ?
          )
        """, (MAX_MESSAGES_PER_CHAT,))


def token_digest(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def issue_token(user_id):
    raw = secrets.token_urlsafe(32)
    with db_connection() as conn:
        conn.execute(
            "INSERT INTO tokens(token_hash, user_id, created_at) VALUES (?, ?, ?)",
            (token_digest(raw), user_id, now_iso()),
        )
    return raw


def current_user():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    token = auth[7:].strip()
    if not token:
        return None
    with db_connection() as conn:
        return conn.execute("""
          SELECT u.id, u.username, t.token_hash
          FROM tokens t JOIN users u ON u.id=t.user_id
          WHERE t.token_hash=?
        """, (token_digest(token),)).fetchone()


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = current_user()
        if not user:
            return jsonify({"error": "Нужно войти в аккаунт."}), 401
        return fn(*args, **kwargs)
    return wrapper


def normalized_username(value):
    return (value or "").strip()


def get_user_by_username(username):
    with db_connection() as conn:
        return conn.execute("SELECT id, username FROM users WHERE username=?", (username,)).fetchone()


def serialize_message(row):
    return dict(row)


def messages_for(user_id, peer_id):
    with db_connection() as conn:
        rows = conn.execute("""
          SELECT m.id, m.sender_id, m.recipient_id, m.body, m.created_at,
                 u.username AS sender_username
          FROM messages m JOIN users u ON u.id=m.sender_id
          WHERE (m.sender_id=? AND m.recipient_id=?)
             OR (m.sender_id=? AND m.recipient_id=?)
          ORDER BY m.id DESC LIMIT ?
        """, (user_id, peer_id, peer_id, user_id, MAX_MESSAGES_PER_CHAT)).fetchall()
    return [serialize_message(r) for r in reversed(rows)]


def trim_chat(conn, a, b):
    conn.execute("""
      DELETE FROM messages WHERE id IN (
        SELECT id FROM messages
        WHERE (sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?)
        ORDER BY id DESC LIMIT -1 OFFSET ?
      )
    """, (a, b, b, a, MAX_MESSAGES_PER_CHAT))


@app.after_request
def cors(response):
    # Token-based auth makes wildcard CORS safe here: no cross-site cookies are used.
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response


@app.route("/api/<path:_path>", methods=["OPTIONS"])
def options(_path):
    return ("", 204)


@app.get("/health")
def health():
    return jsonify({"ok": True})


@app.post("/api/register")
def register():
    data = request.get_json(silent=True) or {}
    username = normalized_username(data.get("username"))
    password = data.get("password") or ""
    if not USERNAME_RE.fullmatch(username):
        return jsonify({"error": "Username: 3–24 символа, только латиница, цифры и _."}), 400
    if len(password) < 6:
        return jsonify({"error": "Пароль должен быть минимум 6 символов."}), 400
    try:
        with db_connection() as conn:
            cur = conn.execute("INSERT INTO users(username,password_hash,created_at) VALUES(?,?,?)",
                               (username, generate_password_hash(password), now_iso()))
            user_id = cur.lastrowid
    except sqlite3.IntegrityError:
        return jsonify({"error": "Такой username уже занят."}), 409
    token = issue_token(user_id)
    return jsonify({"ok": True, "token": token, "user": {"id": user_id, "username": username}})


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    username = normalized_username(data.get("username"))
    password = data.get("password") or ""
    with db_connection() as conn:
        user = conn.execute("SELECT id,username,password_hash FROM users WHERE username=?", (username,)).fetchone()
    if not user or not check_password_hash(user["password_hash"], password):
        return jsonify({"error": "Неверный username или пароль."}), 401
    token = issue_token(user["id"])
    return jsonify({"ok": True, "token": token, "user": {"id": user["id"], "username": user["username"]}})


@app.post("/api/logout")
@login_required
def logout():
    auth = request.headers.get("Authorization", "")
    with db_connection() as conn:
        conn.execute("DELETE FROM tokens WHERE token_hash=?", (token_digest(auth[7:].strip()),))
    return jsonify({"ok": True})


@app.get("/api/me")
def me():
    user = current_user()
    if not user:
        return jsonify({"user": None})
    return jsonify({"user": {"id": user["id"], "username": user["username"]}})


@app.get("/api/chats")
@login_required
def chats():
    me_user = current_user()
    with db_connection() as conn:
        rows = conn.execute("""
          WITH paired AS (
            SELECT CASE WHEN sender_id=? THEN recipient_id ELSE sender_id END peer_id, MAX(id) last_id
            FROM messages WHERE sender_id=? OR recipient_id=? GROUP BY peer_id
          )
          SELECT u.username, m.body AS last_body, m.created_at AS last_at
          FROM paired p JOIN users u ON u.id=p.peer_id JOIN messages m ON m.id=p.last_id
          ORDER BY m.id DESC
        """, (me_user["id"], me_user["id"], me_user["id"])).fetchall()
    return jsonify({"chats": [dict(r) for r in rows]})


@app.get("/api/messages/<username>")
@login_required
def get_messages(username):
    me_user = current_user()
    peer = get_user_by_username(normalized_username(username))
    if not peer or peer["id"] == me_user["id"]:
        return jsonify({"error": "Пользователь не найден."}), 404
    return jsonify({"peer": {"id": peer["id"], "username": peer["username"]},
                    "messages": messages_for(me_user["id"], peer["id"])})


@app.post("/api/messages/<username>")
@login_required
def send_message(username):
    me_user = current_user()
    peer = get_user_by_username(normalized_username(username))
    if not peer or peer["id"] == me_user["id"]:
        return jsonify({"error": "Пользователь не найден."}), 404
    data = request.get_json(silent=True) or {}
    body = (data.get("body") or "").strip()
    if not body:
        return jsonify({"error": "Сообщение пустое."}), 400
    if len(body) > 4000:
        return jsonify({"error": "Максимум 4000 символов."}), 400
    with db_connection() as conn:
        cur = conn.execute("INSERT INTO messages(sender_id,recipient_id,body,created_at) VALUES(?,?,?,?)",
                           (me_user["id"], peer["id"], body, now_iso()))
        message_id = cur.lastrowid
        trim_chat(conn, me_user["id"], peer["id"])
        row = conn.execute("""
          SELECT m.id,m.sender_id,m.recipient_id,m.body,m.created_at,u.username sender_username
          FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=?
        """, (message_id,)).fetchone()
    return jsonify({"ok": True, "message": dict(row)})


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)

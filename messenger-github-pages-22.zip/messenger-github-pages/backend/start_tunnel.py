"""Start a Quick Tunnel and publish its current URL to a Google Apps Script directory."""
import json
import os
import re
import subprocess
import sys
import urllib.request

DIRECTORY_URL = os.environ.get("DIRECTORY_URL", "").strip()
DIRECTORY_SECRET = os.environ.get("DIRECTORY_SECRET", "").strip()
TARGET = os.environ.get("TUNNEL_TARGET", "http://localhost:5000")
URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com", re.I)

if not DIRECTORY_URL or not DIRECTORY_SECRET:
    sys.exit("Set DIRECTORY_URL and DIRECTORY_SECRET before running this script.")


def publish(url):
    data = json.dumps({"secret": DIRECTORY_SECRET, "tunnelUrl": url}).encode("utf-8")
    req = urllib.request.Request(DIRECTORY_URL, data=data, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=20) as response:
        print("Directory updated:", response.read().decode("utf-8", "replace"))


proc = subprocess.Popen(["cloudflared", "tunnel", "--url", TARGET], stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT, text=True, bufsize=1)
published = None
try:
    for line in proc.stdout:
        print(line, end="")
        match = URL_RE.search(line)
        if match and match.group(0) != published:
            published = match.group(0)
            try:
                publish(published)
                print("\nPublic messenger API:", published, "\n")
            except Exception as exc:
                print("\nWARNING: Tunnel started, but directory update failed:", exc, "\n", file=sys.stderr)
finally:
    proc.terminate()

/*
  1) Create a blank Google Sheet.
  2) Extensions -> Apps Script -> replace Code.gs with this file.
  3) Replace the two SETTINGS values below.
  4) Deploy -> New deployment -> Web app:
     Execute as: Me
     Who has access: Anyone
  5) Copy the /exec URL. Put it in github-pages/index.html and use it as DIRECTORY_URL.
*/
const SETTINGS = {
  SPREADSHEET_ID: 'PASTE_YOUR_GOOGLE_SHEET_ID_HERE',
  SECRET: 'REPLACE_WITH_A_LONG_RANDOM_SECRET'
};

function getSheet_() {
  const ss = SpreadsheetApp.openById(SETTINGS.SPREADSHEET_ID);
  let sheet = ss.getSheetByName('Tunnel');
  if (!sheet) {
    sheet = ss.insertSheet('Tunnel');
    sheet.getRange('A1:B2').setValues([
      ['Key', 'Value'],
      ['tunnelUrl', '']
    ]);
  }
  return sheet;
}

function getTunnelUrl_() {
  return String(getSheet_().getRange('B2').getValue() || '').trim();
}

function jsOutput_(text) {
  return ContentService.createTextOutput(text)
    .setMimeType(ContentService.MimeType.JAVASCRIPT);
}

function doGet(e) {
  const callback = String((e.parameter && e.parameter.callback) || '');
  const payload = JSON.stringify({ tunnelUrl: getTunnelUrl_(), updatedAt: new Date().toISOString() });
  // JSONP avoids the cross-origin CORS restriction for a static GitHub Pages site.
  if (/^[A-Za-z_$][\w$]*$/.test(callback)) return jsOutput_(callback + '(' + payload + ');');
  return ContentService.createTextOutput(payload).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  let data = {};
  try { data = JSON.parse((e.postData && e.postData.contents) || '{}'); } catch (_) {}
  if (data.secret !== SETTINGS.SECRET) {
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: 'Unauthorized' }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  const url = String(data.tunnelUrl || '').trim();
  if (!/^https:\/\/[a-z0-9-]+\.trycloudflare\.com$/i.test(url)) {
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: 'Invalid tunnel URL' }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  getSheet_().getRange('B2').setValue(url);
  return ContentService.createTextOutput(JSON.stringify({ ok: true, tunnelUrl: url }))
    .setMimeType(ContentService.MimeType.JSON);
}
